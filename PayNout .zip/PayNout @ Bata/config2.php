<?php
$databaseHost = 'localhost';
$databaseName = 'bata_app';
$databaseUsername = 'root';
$databasePassword = '';

$con = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName);

if(!$con){
	echo "Database Connection Failed";
}


?>