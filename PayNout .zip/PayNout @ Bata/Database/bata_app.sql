-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 10, 2018 at 06:49 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bata_app`
--

-- --------------------------------------------------------

--
-- Table structure for table `colour`
--

CREATE TABLE `colour` (
  `Colour_Name` varchar(10) NOT NULL,
  `Colour_Code` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `colour`
--

INSERT INTO `colour` (`Colour_Name`, `Colour_Code`) VALUES
('Cream', 'C01'),
('Dusky', 'C02'),
('Tawny', 'C03'),
('Taupe', 'C04'),
('Brown', 'C05'),
('Umber', 'C06'),
('Lemon', 'C07'),
('Ochre', 'C08');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `Cust_ID` varchar(20) NOT NULL,
  `Cust_Name` varchar(20) NOT NULL,
  `Cust_User_Name` varchar(20) NOT NULL,
  `Cust_Email` varchar(30) NOT NULL,
  `Cust_Num` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`Cust_ID`, `Cust_Name`, `Cust_User_Name`, `Cust_Email`, `Cust_Num`) VALUES
('C0001', 'Will Smith', 'Smith', 'WSmith_40@Hotmail.com', '019-7783524'),
('C0002', 'Dwayne Johnson', 'Rock', 'WayneRock11@Gmail.com', '011-1177111'),
('C0003', 'Adam Sandler', 'Adam', 'AdSan1019@Yahoo.com', '012-2234190'),
('C0004', 'Janna Nick', 'Nicky', 'Jannah2018@Gmail.com', '018-2233665');

-- --------------------------------------------------------

--
-- Table structure for table `delete_product`
--

CREATE TABLE `delete_product` (
  `Product_ID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `edit_existing_product`
--

CREATE TABLE `edit_existing_product` (
  `Product_ID` int(11) NOT NULL,
  `Product_Gender` varchar(8) NOT NULL,
  `Product_Material` varchar(8) NOT NULL,
  `Product_Colour` varchar(8) NOT NULL,
  `Product_Type` varchar(8) NOT NULL,
  `Product_Size` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `latest_products`
--

CREATE TABLE `latest_products` (
  `Product_Name` varchar(20) NOT NULL,
  `Product_Type` varchar(20) NOT NULL,
  `Product_Category` varchar(20) NOT NULL,
  `Product_Status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `latest_products`
--

INSERT INTO `latest_products` (`Product_Name`, `Product_Type`, `Product_Category`, `Product_Status`) VALUES
('Power XoRise', 'Running Shoes', 'Men', 'Selling Fast'),
('Bata Red Label', 'Heels', 'Women', 'Selling Fast'),
('Bata Red Camel', 'Sandals', 'Women', 'Selling Moderately'),
('B-flex Red Ankle', 'Boots', 'Men', 'Selling Slow'),
('Marvel Avenger Infin', 'Casual Shoes', 'Kids', 'Selling Fast');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `username` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL,
  `category` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`, `category`) VALUES
('Ahmad', '22222', 'user'),
('Ainul', '12345', 'admin'),
('Azlan', '12345', 'admin'),
('Thomas', '11111', 'user'),
('Vivek', '12345', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `material`
--

CREATE TABLE `material` (
  `Material_Types` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `material`
--

INSERT INTO `material` (`Material_Types`) VALUES
('Choose Material'),
('Leather'),
('Rubber'),
('Textile'),
('Foam'),
('Synthetics');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `Product_ID` varchar(10) NOT NULL,
  `Product_Name` varchar(20) NOT NULL,
  `Product_Material` varchar(10) NOT NULL,
  `Product_Colour` varchar(20) NOT NULL,
  `Product_Gender` varchar(10) NOT NULL,
  `Product_Size` varchar(20) NOT NULL,
  `Product_Quantity` int(255) NOT NULL,
  `Product_Price` varchar(11) NOT NULL,
  `Special_Price` varchar(255) NOT NULL,
  `Product_Promo` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`Product_ID`, `Product_Name`, `Product_Material`, `Product_Colour`, `Product_Gender`, `Product_Size`, `Product_Quantity`, `Product_Price`, `Special_Price`, `Product_Promo`) VALUES
('V343456', 'Soccer Boots', 'Synthetics', 'C01', 'Kids', '38,39,40,41,42,43,44', 5, '50.00', '25.00', 'HALFSALE'),
('S123213', 'Bellerina Heels', 'Foam', 'C04', 'Women', '3,4,5,6,7,8,9,10,11,', 5, '80.00', '50.00', 'LADIOSALE');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `Username` varchar(10) NOT NULL,
  `Password` varchar(10) NOT NULL,
  `Email` varchar(20) NOT NULL,
  `Phone_Number` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`Username`, `Password`, `Email`, `Phone_Number`) VALUES
('Vivek', '12345', 'Vivek11@gmail.com', '0123456789'),
('Azlan', '12345', 'Azlan10@Gmail.com', '0123344558');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `Staff_ID` varchar(20) NOT NULL,
  `Staff_Name` varchar(20) NOT NULL,
  `Staff_Email` varchar(30) NOT NULL,
  `Staff_Gender` varchar(10) NOT NULL,
  `Staff_Num` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`Staff_ID`, `Staff_Name`, `Staff_Email`, `Staff_Gender`, `Staff_Num`) VALUES
('SB2012', 'Khairul Fahmi', 'Khai_90@Yahoo.com', 'Male', '123345123'),
('SG1229', 'Afieqah Shuhadah', 'Afiesyue12_Gmail.com', 'Female', '149983452');

-- --------------------------------------------------------

--
-- Table structure for table `top_branches`
--

CREATE TABLE `top_branches` (
  `State_Branch` varchar(20) NOT NULL,
  `Branch_Manager` varchar(30) NOT NULL,
  `Highest_Selling_Product` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `top_branches`
--

INSERT INTO `top_branches` (`State_Branch`, `Branch_Manager`, `Highest_Selling_Product`) VALUES
('Selangor', 'Lau Chong Wei', 'Bata Women Blush Heels'),
('Penang', 'Nurul Farhana Izzati', 'B-flex Women Tobacco Heels'),
('Melaka', 'Raghavendra Ramesh', 'Levis Men Black Casual Shoes'),
('Johor', 'Muhammad Aminuddin', 'BubbleGummers Boys Navy Shoes'),
('Perak', 'Eden Hazard', 'Power Men Running Shoes');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`username`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
