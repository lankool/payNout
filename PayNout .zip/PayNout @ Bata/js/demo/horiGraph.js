var $border_color = "#eee";
var $grid_color = "#eee";
var $default_black = "#666";

var $info = "#5B90BF";
var $danger = "#D66061";
var $warning = "#ffaa3a";
var $success = "#76BBAD";
var $yellow = "#ffee00";
var $facebook = "#4c66a4";
var $twitter = "#00acee";
var $linkedin = "#1a85bd";
var $gplus = "#dc4937";
var $brown = "#ab7967";
  
$(function () {

  var ds=[], data, chartOptions;

  ds.push ([[200, 'Fashion Shoes'],[150, 'Leather Shoes'],[300, 'Canvas Shoes'],[500, 'High Heels'],[100, 'Athletic Shoes']]);
  ds.push ([[300, 'Fashion Shoes'],[200, 'Leather Shoes'],[900, 'Canvas Shoes'],[300, 'High Heels'],[500, 'Athletic Shoes']]);
  ds.push ([[800, 'Fashion Shoes'],[900, 'Leather Shoes'],[200, 'Canvas Shoes'],[100, 'High Heels'],[800, 'Athletic Shoes']]);

  data = [ {
    label: '2016',
    data: ds[0]
  }, {
    label: '2017',
    data: ds[1]
  }, {
    label: '2018',
    data: ds[2]
  }];

  chartOptions = {
    xaxis: {
        
    },
    grid:{
      hoverable: true,
      clickable: false,
      borderWidth: 1,
      tickColor: $border_color,
      borderColor: $grid_color,
    },
    shadowSize: 0,
    bars: {
      horizontal: true,
      show: true,
      barWidth: 8*24*60*60*300,
      barWidth: .2,
      fill: true,
      lineWidth: 1,
      order: true,
      lineWidth: 0,
      fillColor: { colors: [ { opacity: 0.9 }, { opacity: 0.6 } ] }
    },
  
  tooltip: true,

  tooltipOpts: {
    content: '%s: %x'
  },
    colors: [$success, $info, $danger],
  }

  var holder = $('#horizontal-chart');

  if (holder.length) {
      $.plot(holder, data, chartOptions );
  }

});