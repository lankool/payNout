
<?php
//including the database connection file
include_once("config2.php");
//If Add product button is clicked
if(isset($_POST['add']))
	
{


		$pid = mysqli_real_escape_string($con,$_POST['Product_ID']);
		$pname = mysqli_real_escape_string($con,$_POST['Product_Name']);		
		$pQuantity = mysqli_real_escape_string($con,$_POST['Product_Quantity']);
	    $pGender = mysqli_real_escape_string($con,$_POST['options']);
        $pmater =mysqli_real_escape_string($con,$_POST['material']);		
		$pColour = mysqli_real_escape_string($con,$_POST['Product_Colour']);		
		$pSize = mysqli_real_escape_string($con,$_POST['Product_Size']);
		$pPrice = mysqli_real_escape_string($con,$_POST['Product_Price']);
		$promo = mysqli_real_escape_string($con,$_POST['Product_Promo']);
		$sPrice = mysqli_real_escape_string($con,$_POST['Special_Price']);
		
		
	if (empty($pid) || empty($pname) || empty($pQuantity) || empty($pGender) || empty($pmater) || empty($pSize) || empty($pColour) || empty($pPrice) || empty($promo) || empty($sPrice)) 
	{
				
		if(empty($pid)) 
		{
			echo "<script type='text/javascript'>alert('Product ID field is empty!')</script>";
		}		
		if(empty($pname)) 
		{
			echo "<script type='text/javascript'>alert('Product Name field is empty!')</script>";
		}		
		if(empty($pQuantity)) 
		{
			echo "<script type='text/javascript'>alert('Product Quantity field is empty!')</script>";
		}
	    if(empty($pGender)) 
		{
			echo "<script type='text/javascript'>alert('Product Category field is empty!')</script>";
		}
	    if(empty($pSize)) 
		{
			echo "<script type='text/javascript'>alert('Product Size field is empty!')</script>";
		}		
	    if(empty($pmater)) 
		{
			echo "<script type='text/javascript'>alert('Product Material field is empty!')</script>";
		}		
		if(empty($pColour)) 
		{
			echo "<script type='text/javascript'>alert('Product Colour field is empty!')</script>";
		}
		if(empty($pPrice)) 
		{
			echo "<script type='text/javascript'>alert('Product Price field is empty!')</script>";
		}
		if(empty($sPrice)) 
		{
			echo "<script type='text/javascript'>alert('Special Price field is empty!')</script>";
		}		
		if(empty($promo)) 
		{
			echo "<script type='text/javascript'>alert('Promo Code field is empty!')</script>";
		}		
	}
    else{
		//insert data to database
		$sql =mysqli_query($con,"INSERT INTO product(Product_ID,Product_Name,Product_Size,Product_Material,Product_Quantity,Product_Gender,Product_Colour,Product_Price,Product_Promo,Special_Price) VALUES ('$pid','$pname','$pSize','$pmater','$pQuantity','$pGender','$pColour','$pPrice','$promo','$sPrice')");		
		header("Location: Dashboard.php");
	}
    
}

 ?>


<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>PayNOut @ Bata</title>

    <!-- Bootstrap core CSS-->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

    <!-- Page level plugin CSS-->
    <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin.css" rel="stylesheet">

  </head>

  <body id="page-top">

    <nav class="navbar navbar-expand navbar-dark bg-dark static-top">
	 
	  <img class="irc_mi" src="https://vignette.wikia.nocookie.net/logopedia/images/d/dc/Bata.png/revision/latest?cb=20130113010226" 
	  alt="Image result for bata png" onload="typeof google==='object'&amp;&amp;google.aft&amp;&amp;google.aft(this)" width="165" height="75" style="margin-right:40px"> 
	  <a class="navbar-brand mr-1" style="color:white; margin-top:40px;"><b> "Our Customer Is Our Master"</b></a>
	  <a class="navbar-brand mr-1" style="margin-left:50px; color:white;"><b> <h1>FOOTWEAR STORE SYSTEM</h1></b></a>




      

      <!-- Navbar User Profile -->
	    <form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">
      <ul class="navbar-nav ml-auto ml-md-0">
        <li class="nav-item dropdown no-arrow">
          <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fa fa-user-circle fa-3x"></i>
          </a>
          <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
            <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">Logout</a>
          </div>
        </li>
      </ul>
	  </form>

    </nav>

    <div id="wrapper">

      <!-- Sidebar -->
	  
<head>
<title>Font Awesome Icons</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
	  
      <ul class="sidebar navbar-nav">
         <li class="nav-item">
		 <a class="nav-link" href="Dashboard.php">
            <i class="fa fa-dashboard"></i>
            <span>Dashboard</span>
          </a>
        </li>
        <li class="nav-item dropdown">
        <li class="nav-item active">		
          <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fa fa-file-text-o"></i>
            <span>Product Details</span>
          </a>
          <div class="dropdown-menu" aria-labelledby="pagesDropdown">

            <a class="dropdown-item" href="Add.php">Add New Product</a>
            <a class="dropdown-item" href="edit.php">Edit Existing Product</a>
            <a class="dropdown-item" href="Delete.php">Delete Product</a>
          </div>
        </li>
		</li>
			
        <li class="nav-item">
          <a class="nav-link" href="Staff.php">
            <i class="fas fa fa-shirtsinbulk"></i>
            <span>Staff Details</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="Customer.php">
            <i class="fa fa-address-book"></i> 
            <span>Customer Details</span></a>
        </li>
      </ul>

      <div id="content-wrapper">

        <div class="container-fluid">
		
		<body style="background-image:url('images/gg3.jpg'); background-size: 100% 100%;"></body>


          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">Product Details</a></li>
            <li class="breadcrumb-item active">Add New Product</li>
          </ol>

						  <!--    Striped Rows Table  -->
						<div class="panel panel-default">
<br>
							<div class="panel-body">
                          <!--check back the form action -->
                                  <form action= "Add.php" method="post">
									<div class=" input-group">
										<label class="col-md-2" align="right" for="ID"><b>Product ID</b></label>
										<div class="col-md-4">
											<input type="text" class="form-control" name="Product_ID" placeholder="Enter id" /><br>
										</div>

									</div>

									<div class=" input-group">
										<label class="col-md-2" align="right" for="Name"><b>Product Name</b></label>
										<div class="col-md-4">
											<input type="text" class="form-control" name="Product_Name" placeholder="Enter name" /><br>
										</div>
									</div>
									
									<div class="input-group">
										<label class="col-md-2" align="right" for="Product_Material"><b>Product Material</b></label><br><br><br>
										<div class="col-md-4">
											<select class="form-control" name="material">
												<option>Choose Material</option>
												<option value="Leather">Leather</option>
												<option value="Textile">Textile</option>
												<option value="Synthetics">Synthetics</option>
												<option value="Rubber">Rubber</option>
												<option value="Foam">Foam</option>
											</select>
																		   										
										</div>
									</div>									
									
						                  <div class="input-group">
							              <label class="col-md-2" align="right" for="Colour"><b>Product Colour</b></label>										
							              <div class="col-md-4">
							              <input type="text" class="form-control" name="Product_Colour" placeholder="Enter code" />
							              <a href="#" onclick="window.open('colCode.php','newwindow','width=500,height=1000');" > >> List Of Colours << </a><br><br>							
							              </div>
                                          </div>
									
									
									<div class="input-group">
										<label class="col-md-2" align="right" for="Category"><b>Product Category</b></label><br>
										<div class="col-md-4">
										
							       <div style="margin-left:3px">
								    <div class="blog no-margin">
									<div class="blog-body">
										<div class="btn-group" data-toggle="buttons">
											<label class="btn btn-danger">
												<input type="radio" name="options" value="Men"> Men
											</label>
											<label class="btn btn-danger">
												<input type="radio" name="options" value="Women"> Women
											</label>
											<label class="btn btn-danger">
												<input type="radio" name="options" value="Kids"> Kids
											</label>
										</div><br><br>
									</div>
								    </div>
							       </div>																	   										
										</div>
									</div>											
									
									<div class="input-group">
										<label class="col-md-2" align="right" for="Size"><b>Size Distribution</b></label><br>
										<div class="col-md-4">
										
							       <div style="margin-left:3px">
								    <div class="blog no-margin">
									<div class="blog-body">
										<div class="btn-group" data-toggle="buttons">
											<label class="btn btn-danger">
												<input type="radio" name="Product_Size" value="3,4,5,6,7,8,9,10,11,12"> Bata/UK Size
											</label>
											<label class="btn btn-danger">
												<input type="radio" name="Product_Size" value="5.5,6.5,7.5,8.5,9.5,10.5,11.5"> US Size
											</label>
											<label class="btn btn-danger">
												<input type="radio" name="Product_Size" value="38,39,40,41,42,43,44,45"> Europe Size
											</label>
										</div>
									</div>
								    </div>
							       </div>										
                                           <a href="sizetable.php">>> Shoe Size Table << </a>
											
										</div>
									</div><br> 
									
									<div class="input-group">
										<label class="col-md-2" align="right" for="Quantity"><b>Product Quantity</b></label>
										<div class="col-md-4">
											<input type="text" class="form-control" name="Product_Quantity" placeholder="Enter quantity" /><br>										
										</div>
									</div>										
									
									<div class=" input-group">
										<label class="col-md-2" align="right" for="Price"><b>Product Price</b></label>
										<div class="col-md-4">
										    <div class="input-group">
												<span class="input-group-addon btn btn-danger">RM</span>
												<input type="text" class="form-control" name="Product_Price" placeholder="Enter price" /><br>											
											</div>
										</div>
									</div><br>									

									<div class=" input-group">
										<label class="col-md-2" align="right" for="Special"><b>Special Price</b></label>
										<div class="col-md-4">
										    <div class="input-group">
												<span class="input-group-addon btn btn-primary">RM</span>
												<input type="text" class="form-control" name="Special_Price" placeholder="Enter price" /><br>											
											</div>
										</div>
									</div><br>

									<div class=" input-group">
										<label class="col-md-2" align="right" for="codep"><b>Promo Code</b></label>
										<div class="col-md-4">
										    <div class="input-group">
												<span class="input-group-addon btn btn-primary">#</span>
												<input type="text" class="form-control" name="Product_Promo" placeholder="Enter Code" /><br>											
											</div>
										</div>
									</div><br><br>									

				<div class="row">
					<div class="col-md-12" style="text-align:center">
                         <button type="submit" class="btn btn-warning"  name="add">ADD PRODUCT</button>
					</div>
				</div>
				<br />
									
								</form>
							</div>
						</div>						  												  
		</div><br><br>

	  <br><br><a class="navbar-brand mr-1" style="margin-left:500px; color:white;"><b> <h6>COLLABORATIVE PARTNER</h6></b></a>						
<img src="images/PayNOut Logo1.png" width="130" height="130">			

</div> 		  
		  


        <!-- Sticky Footer -->
        <footer class="sticky-footer">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>© AVA Group 2018 | Application Development</span>
            </div>
          </div>
        </footer>

      </div>
      <!-- /.content-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Are You Sure You Want To end your current session?</div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-primary" href="Login.php">Logout</a>
          </div>
        </div>
      </div>
    </div>
		
	
    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Page level plugin JavaScript-->
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="vendor/datatables/jquery.dataTables.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin.min.js"></script>

    <!-- Demo scripts for this page-->
    <script src="js/demo/datatables-demo.js"></script>
    <script src="js/demo/chart-area-demo.js"></script>

  </body>

</html>

