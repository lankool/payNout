<?php
//including the database connection file
include_once("config2.php");

$dcol = mysqli_query($con, "SELECT * FROM colour"); // using mysqli_query instead

echo "<h3>Colour  &nbsp &nbsp &nbsp &nbsp Code</h3>";
while($colour= mysqli_fetch_array($dcol)){
	echo "<h3>";
	echo $colour['Colour_Name'];
	echo "&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp";
	echo $colour['Colour_Code'];
	echo "</h3>";
	
}

?>



<head>
	<title>Colours | PayNOut @ Bata</title>
</head>