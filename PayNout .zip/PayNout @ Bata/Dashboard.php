<?php
//including the database connection file
include_once("config2.php");
?>


<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
	
	
	
	
    
     <title>PayNOut @ Bata</title>

    <!-- Bootstrap core CSS-->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

    <!-- Page level plugin CSS-->
    <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin.css" rel="stylesheet">
	
	 <!-- Table CSS-->
    <link href="vendor/bootstrap/css/new1.css" rel="stylesheet">
	

  </head>

  <body id="page-top">

    <nav class="navbar navbar-expand navbar-dark bg-dark static-top">
	

	  <img class="irc_mi" src="https://vignette.wikia.nocookie.net/logopedia/images/d/dc/Bata.png/revision/latest?cb=20130113010226" 
	  alt="Image result for bata png" onload="typeof google==='object'&amp;&amp;google.aft&amp;&amp;google.aft(this)" width="165" height="75" style="margin-right:40px"> 
	  <a class="navbar-brand mr-1" style="color:white; margin-top:40px;"><b> "Our Customer Is Our Master"</b></a>
	  <a class="navbar-brand mr-1" style="margin-left:50px; color:white;"><b> <h1>FOOTWEAR STORE SYSTEM</h1></b></a>



      

      <!-- Navbar User Profile -->
	    <form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">
      <ul class="navbar-nav ml-auto ml-md-0">
        <li class="nav-item dropdown no-arrow">
          <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fa fa-user-circle fa-3x"></i>
          </a>
          <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
            <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">Logout</a>
          </div>
        </li>
      </ul>
	  </form>

    </nav>

    <div id="wrapper">

      <!-- Sidebar -->
	  
<head>
<title>Font Awesome Icons</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
	  
      <ul class="sidebar navbar-nav">
        <li class="nav-item active">
          <a class="nav-link" href="Dashboard.php">
            <i class="fa fa-dashboard"></i>
            <span>Dashboard</span>
          </a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fa fa-file-text-o"></i>
            <span>Product Details</span>
          </a>
          <div class="dropdown-menu" aria-labelledby="pagesDropdown">

            <a class="dropdown-item" href="Add.php">Add New Product</a>
            <a class="dropdown-item" href="edit.php">Edit Existing Product</a>
            <a class="dropdown-item" href="delete.php">Delete Product</a>
          </div>
        </li>
			
        <li class="nav-item">
          <a class="nav-link" href="Staff.php">
            <i class="fas fa fa-shirtsinbulk"></i>
            <span>Staff Details</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="Customer.php">
            <i class="fa fa-address-book"></i> 
            <span>Customer Details</span></a>
        </li>
      </ul>

      <div id="content-wrapper">

        <div class="container-fluid">
		
		<body style="background-image:url('images/gg3.jpg'); background-size: 100% 100%;"></body>

		
          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Overview</li>
          </ol>

<html>
  <head>
  <style type="text/css">
  #wrap {
	  width:980px;

  }
  .left {
	  margin-top:20px;
	  float:left;	  
  }
  .right {
	  margin-top:20px;	  
	  width:260px;
      float:right;	  
  }
  </style>
  </head>
  <body>

    <div id="wrap">
	<div class="left">
	
<!--<div class="content-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-md-10" style="margin-left:100px; margin-top:450px; width:600px;">
                        <div class="panel-body"> -->
						
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['bar']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Product', '2018', '2017', '2016'],
          ['Canvas Shoes', 1000, 400, 200],
          ['High Heels', 1170, 460, 250],
          ['Casual Shoes', 660, 1120, 300],
          ['Native Shoes', 1030, 540, 350]
        ]);

        var options = {
          chart: {
            title: 'Performance By Product',
            subtitle: 'Product Sales Trend, 2016-2018',
          },
          bars: 'horizontal' // Required for Material Bar Charts.
        };

        var chart = new google.charts.Bar(document.getElementById('barchart_material'));

        chart.draw(data, google.charts.Bar.convertOptions(options));
      }
    </script>  
  
    <div id="barchart_material" style=" margin-left:20px; width: 700px; height: 400px; "></div>
						
                      <!--  </div><br>
                </div>
			</div>
        </div>
    </div> -->
	

    </div>
 	<div class="right">   
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
	<script type="text/javascript">
	

      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

	  
      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['Task', 'Percentage of conquerence'],
          ['Adidas',40],
          ['Bata',10],
          ['Puma',10],
          ['Umbro',5],
          ['Nike',35]
        ]);

        var options = {
          title: 'Footwear Retailing Company Conquerence'
		};

        var chart = new google.visualization.PieChart(document.getElementById('piechart'));

        chart.draw(data, options);
      }
    </script>	 
    <div id="piechart" style="width:500px; height:400px;"></div>	
    </div>
	</div>
	</body>
	</html>

<!--<div class="content-wrapper">
        <div class="container">
            <div class="row"> -->
                <div class="col-md-10" style="margin-left:155px; margin-top:500px; margin-bottom:82px; width:900px;">
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table id= "subject-grid" class="table table-striped">
								<i class="fa fa-line-chart"><b> Top Performing Branches</b></i><br><br>
                                    <thead>
                                        <tr>
										    <th>No</th>
                                            <th>State Branch</th>
                                            <th>Highest Selling Product</th>
                                            <th>Branch Manager</th>
											<th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
										<?php 
											$i = 1;
											$query="SELECT * FROM top_branches";
                                            $result=mysqli_query($con,$query);
                                            while ($row=mysqli_fetch_array($result)){ 
												//index
												echo "<tr>";
												echo "<td>".$i."</td>";
												
												//Product ID
												$sb = $row['State_Branch'];
												echo "<td>".$sb."</td>";
												
												//Product Price
												$hsp= $row['Highest_Selling_Product'];
												echo "<td>".$hsp."</td>";
												
												//Product Name
												$bm= $row['Branch_Manager'];
												echo "<td>".$bm."</td>";
												
												if($i==1){												
                                                echo "<td><a href=\"Manager1.php\"><i class='fa fa-address-card-o'></i></a></td>";												
                                                }
												if($i==2){												
                                                echo "<td><a href=\"Manager2.php\"><i class='fa fa-address-card-o'></i></a></td>";												
                                                }
												if($i==3){												
                                                echo "<td><a href=\"Manager3.php\"><i class='fa fa-address-card-o'></i></a></td>";												
                                                }
												if($i==4){												
                                                echo "<td><a href=\"Manager4.php\"><i class='fa fa-address-card-o'></i></a></td>";												
                                                }
												if($i==5){												
                                                echo "<td><a href=\"Manager5.php\"><i class='fa fa-address-card-o'></i></a></td>";												
                                                }												
												$i++;
											}
										?>
                                    </tbody>
                                </table>
                            </div>
                        </div><br><br><br><br>
						
	  <br><br><a class="navbar-brand mr-1" style="margin-left:320px; color:black;"><b> <h6>COLLABORATIVE PARTNER</h6></b></a>						
<img src="images/PayNOut Logo1.png" width="130" height="130">						
                </div>
		<!--	</div>
        </div>
    </div> -->
        <!-- /.container-fluid -->

        <!-- Sticky Footer -->
        <footer class="sticky-footer">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>© AVA Group 2018 | Application Development</span>
            </div>
          </div>
        </footer>

      </div>
      <!-- /.content-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Are You Sure You Want To end your current session?</div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-primary" href="Login.php">Logout</a>
          </div>
        </div>
      </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Page level plugin JavaScript-->
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="vendor/datatables/jquery.dataTables.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin.min.js"></script>

    <!-- Demo scripts for this page-->
    <script src="js/demo/datatables-demo.js"></script>
    <script src="js/demo/chart-area-demo.js"></script>

	

  </body>

</html>
