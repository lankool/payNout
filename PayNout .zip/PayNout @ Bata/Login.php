<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
	
	
	
	
    
     <title>PayNOut @ Bata</title>

    <!-- Bootstrap core CSS-->
    <link href="vendor/bootstrap/css/bootstrap.min.login.css" rel="stylesheet">

	 <link rel="stylesheet" href="css/style(login).css">

  </head>

  <body id="page-top">

    <nav class="navbar navbar-expand navbar-dark bg-dark static-top">
	

	  <img class="irc_mi" src="https://vignette.wikia.nocookie.net/logopedia/images/d/dc/Bata.png/revision/latest?cb=20130113010226" 
	  alt="Image result for bata png" onload="typeof google==='object'&amp;&amp;google.aft&amp;&amp;google.aft(this)" width="165" height="75" style="margin-right:40px"> 
	  <a class="navbar-brand mr-1" style="color:white; margin-top:40px"><b> "Our Customer Is Our Master"</b></a>
	  <a class="navbar-brand mr-1" style="color:white; margin-left:30px"><b> <h1>FOOTWEAR STORE SYSTEM</h1></b></a>

    </nav>

    <div id="wrapper">

      <!-- Sidebar -->
	    
      <div id="content-wrapper">

        <div class="container-fluid">
		
		<body style="background-image:url('images/img2.jpg'); background-size: 100%;"></body>

<body>
  <div class="header">
  	<h2>Welcome Admin!</h2>
  </div>
	 
  <form method="post" action="Login.php">
  	<div class="input-group">
  		<label>Username</label>
  		<input type="text" name="username" autofocus />
  	</div>
  	<div class="input-group">
  		<label>Password</label>
  		<input type="password" name="password"/>
  	</div>
  	<div class="input-group">
  		<button type="submit" class="btn" name="login">Login</button>
  	</div>
  	<p>
  	<a href="#"><h6>Forgot Password?<h6> </a>
    <h6>Contact Admin Office : 09-2311256</h6>
 </p>
  </form>
</body>
		
		
     </div>
      <!-- /.content-wrapper -->

    </div>
    <!-- /#wrapper -->
		
</div>		

        <!-- /.container-fluid -->

        <!-- Sticky Footer -->
        <footer class="sticky-footer">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>© AVA Group 2018 | Application Development</span>
            </div>
          </div>
        </footer>


	


    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Page level plugin JavaScript-->
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="vendor/datatables/jquery.dataTables.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin.min.js"></script>

    <!-- Demo scripts for this page-->
    <script src="js/demo/datatables-demo.js"></script>
    <script src="js/demo/chart-area-demo.js"></script>

  </body>

</html>

<?php
 include('config2.php');

if(isset($_POST['login']))
{
    $username=$_POST['username'];
    $password=$_POST['password'];

    $check="SELECT * FROM login WHERE username='$username' AND password='$password'";

    $run=mysqli_query($con,$check);

    if(mysqli_num_rows($run))
     {
		
		$find = mysqli_query($con, "SELECT * FROM login WHERE username='$username' AND password='$password'");
		$row=mysqli_fetch_assoc($find);
				
		if($row['username']== $username && $row['password']==$password)
		{		
		echo "<script>window.open('Dashboard.php','_self')</script>";
		$_SESSION['username']=$username;
		$_SESSION['password']=$password;}
	 }
		
    else
    {
        echo "<script>alert('Username or password is incorrect!')</script>";
    }		
     

}
?>
