<?php
//including the database connection file
include("config2.php");

//getting id of the data from url
$pid = $_GET['Product_ID'];

//deleting the row from table
$del = mysqli_query($con, "DELETE FROM product WHERE Product_ID='$pid'");

//redirecting to the display page (index.php)
//header("Location:ad-sectionview.php");
header("Location: delete.php?id=$pid");
?>