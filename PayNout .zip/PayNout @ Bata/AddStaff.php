
<?php
//including the database connection file
include_once("config2.php");
//If Add product button is clicked
if(isset($_POST['add']))
	
{


		$sid = mysqli_real_escape_string($con,$_POST['Staff_ID']);
		$sname = mysqli_real_escape_string($con,$_POST['Staff_Name']);		
		$email = mysqli_real_escape_string($con,$_POST['email']);
		$sGender = mysqli_real_escape_string($con,$_POST['gender']);
	    $phone = mysqli_real_escape_string($con,$_POST['phone']);		
				
	if (empty($sid) || empty($sname) || empty($email) || empty($sGender) || empty($phone)) 
	{
				
		if(empty($sid)) 
		{
			echo "<script type='text/javascript'>alert('Staff ID field is empty!')</script>";
		}		
		if(empty($sname)) 
		{
			echo "<script type='text/javascript'>alert('Staff Name field is empty!')</script>";
		}		
		if(empty($email)) 
		{
			echo "<script type='text/javascript'>alert('Email Address field is empty!')</script>";
		}
	    if(empty($sGender)) 
		{
			echo "<script type='text/javascript'>alert('Staff Gender field is empty!')</script>";
		}		
		if(empty($phone)) 
		{
			echo "<script type='text/javascript'>alert('Phone Number field is empty!')</script>";
		}
		
	}
    else{
		//insert data to database
		$sql =mysqli_query($con,"INSERT INTO staff(Staff_ID,Staff_Name,Staff_Email,Staff_Num,Staff_Gender) VALUES ('$sid','$sname','$email','$phone','$sGender')");		
				header("Location: Staff.php");
	}
    
	
}

 ?>



<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>PayNOut @ Bata</title>

    <!-- Bootstrap core CSS-->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

    <!-- Page level plugin CSS-->
    <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin.css" rel="stylesheet">
	
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css">
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script> 
    <script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/2.14.1/moment.min.js"></script> 
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
		
  </head>

  <body id="page-top">

    <nav class="navbar navbar-expand navbar-dark bg-dark static-top">
	 
	  <img class="irc_mi" src="https://vignette.wikia.nocookie.net/logopedia/images/d/dc/Bata.png/revision/latest?cb=20130113010226" 
	  alt="Image result for bata png" onload="typeof google==='object'&amp;&amp;google.aft&amp;&amp;google.aft(this)" width="165" height="75" style="margin-right:40px"> 
	  <a class="navbar-brand mr-1" style="color:white; margin-top:40px;"><b> "Our Customer Is Our Master"</b></a>
	  <a class="navbar-brand mr-1" style="margin-left:50px; color:white;"><b> <h1>FOOTWEAR STORE SYSTEM</h1></b></a>




      

      <!-- Navbar User Profile -->
	    <form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">
      <ul class="navbar-nav ml-auto ml-md-0">
        <li class="nav-item dropdown no-arrow">
          <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fa fa-user-circle fa-3x"></i>
          </a>
          <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
            <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">Logout</a>
          </div>
        </li>
      </ul>
	  </form>

    </nav>

    <div id="wrapper">

      <!-- Sidebar -->
	  
<head>
<title>Font Awesome Icons</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
	  
      <ul class="sidebar navbar-nav">
         <li class="nav-item">
		 <a class="nav-link" href="Dashboard.php">
            <i class="fa fa-dashboard"></i>
            <span>Dashboard</span>
          </a>
        </li>
        <li class="nav-item dropdown">
        <li class="nav-item active">		
          <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fa fa-file-text-o"></i>
            <span>Product Details</span>
          </a>
          <div class="dropdown-menu" aria-labelledby="pagesDropdown">

            <a class="dropdown-item" href="Add.php">Add New Product</a>
            <a class="dropdown-item" href="edit.php">Edit Existing Product</a>
            <a class="dropdown-item" href="Delete.php">Delete Product</a>
          </div>
        </li>
		</li>
			
        <li class="nav-item">
          <a class="nav-link" href="Staff.php">
            <i class="fas fa fa-shirtsinbulk"></i>
            <span>Staff Details</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="Customer.php">
            <i class="fa fa-address-book"></i> 
            <span>Customer Details</span></a>
        </li>
      </ul>

      <div id="content-wrapper">

        <div class="container-fluid">
		
		<body style="background-image:url('images/gg3.jpg'); background-size: 100% 100%;"></body>


          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">Staff Details</a></li>
            <li class="breadcrumb-item active">Add New Staff</li>
          </ol>

						  <!--    Striped Rows Table  -->
						<div class="panel panel-default">
<br>
							<div class="panel-body">
                          <!--check back the form action -->
                                  <form action= "AddStaff.php" method="post">
									<div class=" input-group">
										<label class="col-md-2" align="right" for="ID"><b>Staff ID</b></label>
										<div class="col-md-4">
											<input type="text" class="form-control" name="Staff_ID" placeholder="Enter id" /><br>
										</div>

									</div>

									<div class=" input-group">
										<label class="col-md-2" align="right" for="Name"><b>Staff Name</b></label>
										<div class="col-md-4">
											<input type="text" class="form-control" name="Staff_Name" placeholder="Enter name" /><br>
										</div>
									</div>
									
									<div class="input-group">
										<label class="col-md-2" align="right" for="Size"><b>Staff Gender</b></label><br>
										<div class="col-md-4">
										
							       <div style="margin-left:3px">
								    <div class="blog no-margin">
									<div class="blog-body">
										<div class="btn-group" data-toggle="buttons">
											<label class="btn btn-danger">
												<input type="radio" name="gender" value="Male"> Male
											</label>
											<label class="btn btn-danger">
												<input type="radio" name="gender" value="Female"> Female
											</label>	
										</div>
									</div>
								    </div>
							       </div>																					
										</div>
									</div><br>								
									
						                  <div class="input-group">
							              <label class="col-md-2" align="right" for="email"><b>Email Address</b></label>										
							              <div class="col-md-4">
							              <input type="text" class="form-control" name="email" placeholder="Enter email" />							
							              </div>
                                          </div><br>
																				
									
									<div class="input-group">
										<label class="col-md-2" align="right" for="phone"><b>Phone number</b></label>
										<div class="col-md-4">
											<div class="input-group">
												<span class="input-group-addon btn btn-danger">+60</span>
											<input type="text" class="form-control" name="phone" placeholder="Enter phone number" /><br>											
											</div>										
										</div>
									</div><br><br>
																	   
																									

				<div class="row">
					<div class="col-md-12" style="text-align:center">
                         <button type="submit" class="btn btn-warning"  name="add">ADD STAFF</button>
					</div>
				</div>
				<br />
									
								</form>
							</div>
						</div>						  												  
		</div>

	  <br><br><a class="navbar-brand mr-1" style="margin-left:500px; color:white;"><b> <h6>COLLABORATIVE PARTNER</h6></b></a>						
<img src="images/PayNOut Logo1.png" width="130" height="130">		

</div> 		  
		  


        <!-- Sticky Footer -->
        <footer class="sticky-footer">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>© AVA Group 2018 | Application Development</span>
            </div>
          </div>
        </footer>

      </div>
      <!-- /.content-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Are You Sure You Want To end your current session?</div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-primary" href="Login.php">Logout</a>
          </div>
        </div>
      </div>
    </div>
		
	
    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Page level plugin JavaScript-->
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="vendor/datatables/jquery.dataTables.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin.min.js"></script>

    <!-- Demo scripts for this page-->
    <script src="js/demo/datatables-demo.js"></script>
    <script src="js/demo/chart-area-demo.js"></script>
	
	

  </body>

</html>

