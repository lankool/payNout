
<?php
//including the database connection file
include_once("config2.php");
?>

<?php

$pid = $_GET['id'];
$dpro = mysqli_query($con, "SELECT * FROM product WHERE Product_ID='$pid'"); // using mysqli_query instead
$res = mysqli_fetch_array($dpro);
	$pid = $res['Product_ID'];
	$pname = $res['Product_Name'];
	$pQuantity = $res['Product_Quantity'];
	$pmater = $res['Product_Material'];
	$pGender = $res['Product_Gender'];
	$pColour = $res['Product_Colour'];
	$pSize = $res['Product_Size'];
	$pPrice = $res['Product_Price'];
	$promo = $res['Product_Promo'];
	$sPrice = $res['Special_Price'];	
?>
		
<?php
//including the database connection file
include_once("config2.php");
//If Add product button is clicked
if(isset($_POST['update']))
	
{
		
		$pQuantity = mysqli_real_escape_string($con,$_POST['Product_Quantity']);		
		$pColour = mysqli_real_escape_string($con,$_POST['Product_Colour']);		
		$pSize = mysqli_real_escape_string($con,$_POST['Product_Size']);
		$promo = mysqli_real_escape_string($con,$_POST['Product_Promo']);
		$sPrice = mysqli_real_escape_string($con,$_POST['Special_Price']);
		
		
	if (empty($pQuantity) || empty($pColour) || empty($promo) || empty($sPrice)) 
	{
	
		if(empty($pQuantity)) 
		{
			echo "<script type='text/javascript'>alert('Product Quantity field is empty!')</script>";
		}		
		if(empty($pColour)) 
		{
			echo "<script type='text/javascript'>alert('Product Colour field is empty!')</script>";
		}
		if(empty($sPrice)) 
		{
			echo "<script type='text/javascript'>alert('Special Price field is empty!')</script>";
		}		
		if(empty($promo)) 
		{
			echo "<script type='text/javascript'>alert('Promo Code field is empty!')</script>";
		}		
	}
    else{
		//insert data to database
		$sql =mysqli_query($con,"UPDATE product SET Product_Quantity='$pQuantity',Product_Colour='$pColour',Product_Promo='$promo',Special_Price='$sPrice' WHERE Product_ID='$pid'");
				header("Location: editSINYEE.php");
	}
    
	
}

 ?>



<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>PayNout @ Bata</title>

    <!-- Bootstrap core CSS-->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

    <!-- Page level plugin CSS-->
    <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin.css" rel="stylesheet">

  </head>

  <body id="page-top">

    <nav class="navbar navbar-expand navbar-dark bg-dark static-top">
	 
	  <img class="irc_mi" src="https://vignette.wikia.nocookie.net/logopedia/images/d/dc/Bata.png/revision/latest?cb=20130113010226" 
	  alt="Image result for bata png" onload="typeof google==='object'&amp;&amp;google.aft&amp;&amp;google.aft(this)" width="165" height="75" style="margin-right:40px"> 
	  <a class="navbar-brand mr-1" style="color:white; margin-top:40px;"><b> "Our Customer Is Our Master"</b></a>
	  <a class="navbar-brand mr-1" style="margin-left:50px; color:white;"><b> <h1>FOOTWEAR STORE SYSTEM</h1></b></a>




      

      <!-- Navbar User Profile -->
	    <form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">
      <ul class="navbar-nav ml-auto ml-md-0">
        <li class="nav-item dropdown no-arrow">
          <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fa fa-user-circle fa-3x"></i>
          </a>
          <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
            <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">Logout</a>
          </div>
        </li>
      </ul>
	  </form>

    </nav>

    <div id="wrapper">

      <!-- Sidebar -->
	  
<head>
<title>Font Awesome Icons</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
	  
      <ul class="sidebar navbar-nav">
         <li class="nav-item">
		 <a class="nav-link" href="Dashboard.php">
            <i class="fa fa-dashboard"></i>
            <span>Dashboard</span>
          </a>
        </li>
        <li class="nav-item dropdown">
        <li class="nav-item active">		
          <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fa fa-file-text-o"></i>
            <span>Product Details</span>
          </a>
          <div class="dropdown-menu" aria-labelledby="pagesDropdown">

            <a class="dropdown-item" href="Add.php">Add New Product</a>
            <a class="dropdown-item" href="edit.php">Edit Existing Product</a>
            <a class="dropdown-item" href="delete.php">Delete Product</a>
          </div>
        </li>
		</li>
			
        <li class="nav-item">
          <a class="nav-link" href="Staff.php">
            <i class="fas fa fa-shirtsinbulk"></i>
            <span>Staff Details</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="Customer.php">
            <i class="fa fa-address-book"></i> 
            <span>Customer Details</span></a>
        </li>
      </ul>

      <div id="content-wrapper">

        <div class="container-fluid">
		
		<body style="background-image:url('images/gg3.jpg'); background-size: 100% 100%;"></body>

          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">Product Details</a></li>
            <li class="breadcrumb-item active">Edit Product</li>
          </ol>

						  <!--    Striped Rows Table  -->
						<div class="panel panel-default">
<br>
							<div class="panel-body">
                          <!--check back the form action -->
                                  <form action= "edit2.php" method="post">
					             <input type="hidden" name="update" value="true"/>								  
									<div class=" input-group">
										<label class="col-md-2" align="right" for="ID"><b>Product ID</b></label>
										<div class="col-md-4">
											<input type="text" class="form-control" name="Product_ID" value="<?php echo $pid;?>" readonly /><br>
										</div>

									</div>

									<div class=" input-group">
										<label class="col-md-2" align="right" for="Name"><b>Product Name</b></label>
										<div class="col-md-4">
											<input type="text" class="form-control" name="Product_Name" value="<?php echo $pname;?>" readonly /><br>
										</div>
									</div>									
									<div class="input-group">
										<label class="col-md-2" align="right" for="Product_Material"><b>Product Material</b></label><br><br><br>
										<div class="col-md-4">
											<input type="text" class="form-control" name="Product_Material" value="<?php echo $pmater;?>" readonly /><br>																		   										
										</div>
									</div>						

									<div class="input-group">
										<label class="col-md-2" align="right" for="Category"><b>Product Category</b></label><br>
										<div class="col-md-4">
											<input type="text" class="form-control" name="Product_Gender" value="<?php echo $pGender;?>" readonly /><br>																	   										
										</div>
									</div>										
									
									<div class="input-group">
										<label class="col-md-2" align="right" for="Size"><b>Size Distribution</b></label><br>
										<div class="col-md-4">										
											<input type="text" class="form-control" name="Product_Size" value="<?php echo $pSize;?>" readonly /><br>
										</div>
									</div> 

									<div class=" input-group">
										<label class="col-md-2" align="right" for="Price"><b>Product Price</b></label>
										<div class="col-md-4">
										    <div class="input-group">
												<span class="input-group-addon btn btn-danger">RM</span>
												<input type="text" class="form-control" name="Product_Price" value="<?php echo $pPrice;?>" readonly /><br>											
											</div>
										</div>
									</div><br>
									
						                  <div class="input-group">
							              <label class="col-md-2" align="right" for="Colour"><b>Product Colour</b></label>										
							              <div class="col-md-4">
							              <input type="text" class="form-control" name="Product_Colour" value="<?php echo $pColour;?>" />
							              <a href="#" onclick="window.open('colCode.php','newwindow','width=500,height=1000');" > >> List Of Colours << </a><br><br>							
							              </div>
                                          </div>									

									
									<div class="input-group">
										<label class="col-md-2" align="right" for="Quantity"><b>Product Quantity</b></label>
										<div class="col-md-4">
											<input type="text" class="form-control" name="Product_Quantity" value="<?php echo $pQuantity;?>" /><br>										
										</div>
									</div>																			

									<div class=" input-group">
										<label class="col-md-2" align="right" for="Special"><b>Special Price</b></label>
										<div class="col-md-4">
										    <div class="input-group">
												<span class="input-group-addon btn btn-primary">RM</span>
												<input type="text" class="form-control" name="Special_Price" value="<?php echo $sPrice;?>" /><br>											
											</div>
										</div>
									</div><br>

									<div class=" input-group">
										<label class="col-md-2" align="right" for="codep"><b>Promo Code</b></label>
										<div class="col-md-4">
										    <div class="input-group">
												<span class="input-group-addon btn btn-primary">#</span>
												<input type="text" class="form-control" name="Product_Promo" value="<?php echo $promo;?>" /><br>											
											</div>
										</div>
									</div><br><br>									
				<div class="row">
					<div class="col-md-12" style="text-align:center">
						<input type="hidden" name="Product_ID" value="<?php echo $_GET['Product_ID'];?>" >
                         <button type="submit" class="btn btn-warning"  name="update">UPDATE</button>
					</div>
				</div>
				<br />									
								</form>
							</div>
						</div>
						  
						  
						  
					</div>
					
	  <br><br><a class="navbar-brand mr-1" style="margin-left:500px; color:white;"><b> <h6>COLLABORATIVE PARTNER</h6></b></a>						
<img src="images/PayNOut Logo1.png" width="130" height="130">							
					
            </div> 		  
		  


        <!-- Sticky Footer -->
        <footer class="sticky-footer">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>© AVA Group 2018 | Application Development</span>
            </div>
          </div>
        </footer>

      </div>
      <!-- /.content-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Are You Sure You Want To end your current session?</div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-primary" href="Login.php">Logout</a>
          </div>
        </div>
      </div>
    </div>
		
	
    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Page level plugin JavaScript-->
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="vendor/datatables/jquery.dataTables.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin.min.js"></script>

    <!-- Demo scripts for this page-->
    <script src="js/demo/datatables-demo.js"></script>
    <script src="js/demo/chart-area-demo.js"></script>

  </body>

</html>
